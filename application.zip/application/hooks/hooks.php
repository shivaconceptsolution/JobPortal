<?php
function myinfo()
{
 echo "<script>alert('provide 25% discount to girls only')</script>";
}

?>