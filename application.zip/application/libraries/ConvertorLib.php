<?php


class Convertorlib
{

function convertToRupees($amt)
{
  $a =$amt*72;
  return "$a RS" ;
}
function convertToDollar($amt)
{
   $a = $amt/72;
  return "$a $";
}

}


?>