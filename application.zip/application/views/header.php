<html>
<head>
    <link href="<?php echo base_url(); ?>assets/css/style.css" type="text/css" rel="stylesheet" />

</head>
<body>
    <header>
   
    <nav>
     <ul><li><a href="<?php echo site_url(); ?>/JobSeekerController/index">Home</a></li>
     <li><a href="<?php echo site_url(); ?>/JobSeekerController/aboutus">About us</a></li>
     <li><a href="<?php echo site_url(); ?>/JobSeekerController/services">Services</a></li>
     <li><a href="<?php echo site_url(); ?>/JobSeekerController/gallery">Gallery</a></li>
     <li><a href="<?php echo site_url(); ?>/JobSeekerController/contactus">Contact us</a></li>
    </ul>

    </nav>

    </header>