<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
RESULT SCORE CARD
<hr>
<?php
echo $res;
?>
</body>
</html>