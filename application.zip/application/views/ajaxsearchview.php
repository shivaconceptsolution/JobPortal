<!DOCTYPE html>
<html>
<head>
	<title></title>
   <script type="text/javascript">
   	
     function searchdata(a)
     {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange=function()
        {
          document.getElementById("res").innerHTML = xmlhttp.responseText;
        }

        xmlhttp.open("POST","<?php echo site_url(); ?>/SearchController/searchdata/"+a,true);
        xmlhttp.send();


     }

   </script>

</head>
<body>

<input type="text" id="txtsearch" placeholder="Enter char" onkeyup="searchdata(this.value)" />

<div id="res"></div>
</body>
</html>