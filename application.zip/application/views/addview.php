<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php
echo form_open("AdditionController/index");
echo form_input("txtnum1","",array("placeholder"=>"Enter First Number")),"<br><br>";
echo form_input("txtnum2","",array("placeholder"=>"Enter Second Number")),"<br><br>";
echo form_submit("btnsubmit","Add");


echo form_close();
echo "<br>";
echo @$result;
?>
</body>
</html>