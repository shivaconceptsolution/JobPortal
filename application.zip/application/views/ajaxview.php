<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

if(is_array($data))
   {
   foreach ($data as $x) {
    foreach ($x as $y)
    {
     echo $y," ";
    }
    echo "<hr>";
   }

   }
   else
    echo $data;
?>
</body>
</html>