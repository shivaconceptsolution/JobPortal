<?php

class CartController extends CI_Controller
{
    function __construct()
    {
    	parent::__construct();
    	$this->load->library('cart');
    }

    function index()
    {
       $data = array(
        array(
                'id'      => 'sku_123ABC',
                'qty'     => 1,
                'price'   => 100,
                'name'    => 'T-Shirt',
                'options' => array('Size' => 'L', 'Color' => 'Red')
        ),
        array(
                'id'      => 'sku_567ZYX',
                'qty'     => 1,
                'price'   => 1200,
                'name'    => 'Shoes'
        ),
        array(
                'id'      => 'sku_965QRS',
                'qty'     => 1,
                'price'   => 2000,
                'name'    => 'Watch'
        ));

       $this->cart->insert($data);
       $this->load->view('cartview');

    }

    function updatecart()
    {

    	$data = array(
        array(
                'rowid'   => '0256a32c98ce49afbe2a4eb8c96c5884',
                'qty'     => $this->input->post('txt1')
        ),
        array(
                'rowid'   => '90972f7cfcd380a9fa7821d30a9b2fb2',
                'qty'     => $this->input->post('txt2')
        ),
        array(
                'rowid'   => '46acd2fb2e0d0b4a29c67e7ddf1c8946',
                'qty'     => $this->input->post('txt3')
        )
);

$this->cart->update($data);
 $this->load->view('cartview');
    }

}




?>