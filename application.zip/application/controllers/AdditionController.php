<?php

class AdditionController extends CI_Controller
{
     function __construct()
     {
     	parent::__construct();
     	$this->load->helper('form');
     }

     function index()
     {
     	$res= "";
     	if($this->input->post('btnsubmit'))
     	{
            $res = $this->input->post('txtnum1') + $this->input->post('txtnum2');

     	}

     	$this->load->view('addview',array("result"=>$res));
     }



}