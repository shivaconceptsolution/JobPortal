<?php
class SearchController extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Regmodel');
	} 
    function index()
    {
    	$this->load->view('ajaxsearchview');
    }
    function searchdata($id)
    {
    	$res = $this->Regmodel->showreg($id);
    	if(count($res)>0)
    	{
        $this->load->view('ajaxview',array("data"=>$res));
        }
        else
        {
        	 $this->load->view('ajaxview',array("data"=>"NO RECORD FOUND"));
        }
    }

}




?>