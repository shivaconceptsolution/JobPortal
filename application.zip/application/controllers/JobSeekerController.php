<?php

class JobSeekerController extends CI_Controller
{
    function index()
    {
        $this->load->view('header');
        $this->load->view('frontview');
        $this->load->view('footer');
    }
    function aboutus()
    {
        $this->load->view('header');
        $this->load->view('aboutview');
        $this->load->view('footer');
    }
    function services()
    {
        $this->load->view('header');
        $this->load->view('servicesview');
        $this->load->view('footer');
    }
    function gallery()
    {
        $this->load->view('header');
        $this->load->view('galleryview');
        $this->load->view('footer');
    }
    function contactus()
    {
        $this->load->view('header');
        $this->load->view('contactview');
        $this->load->view('footer');
    }

}



?>